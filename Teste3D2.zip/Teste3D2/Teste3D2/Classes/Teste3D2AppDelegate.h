//
//  Teste3D2AppDelegate.h
//  Teste3D2
//
//  Created by Hamlet Pessoa Farias Junior on 04/12/11.
//  Copyright Individual 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GLView;

@interface Teste3D2AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    GLView *glView;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet GLView *glView;

@end

