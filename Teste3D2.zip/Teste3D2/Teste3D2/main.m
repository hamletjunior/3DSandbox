//
//  main.m
//  Teste3D2
//
//  Created by Hamlet Pessoa Farias Junior on 04/12/11.
//  Copyright (c) 2011 Individual. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    int retVal =0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, nil);
    }
    return retVal;
}
