//
//  GLViewController.h
//  Teste3D2
//
//  Created by Hamlet Pessoa Farias Junior on 04/12/11.
//  Copyright Individual 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GLView.h"

@interface GLViewController : UIViewController <GLViewDelegate>
{
}
@end
