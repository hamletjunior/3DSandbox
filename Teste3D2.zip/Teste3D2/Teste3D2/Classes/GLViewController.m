//
//  GLViewController.m
//  Teste
//
//  Created by Hamlet Pessoa Farias Junior on 29/11/11.
//  Copyright Individual 2011. All rights reserved.
//

#import "GLViewController.h"
#import "ConstantsAndMacros.h"
#import "OpenGLCommon.h"
#import "OpenGLTexture3D.h"
#import "Earth.h"

@interface GLViewController ()
@property (nonatomic, retain) OpenGLTexture3D *texture;
@end

@implementation GLViewController
@synthesize texture;
- (void)drawView:(UIView *)theView
{
    glColor4f(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glColor4f(1, 1, 1, 1);
    glEnable(GL_TEXTURE_2D);
    [texture bind];
    glEnable(GL_CULL_FACE);
    
    glLoadIdentity();
    glTranslatef(0, 0.1, -3);
    //    glScalef(0.5, 0.5, 0.5);
    
    // Quick and dirty hack to make the model rotate:
    static float t = 0.0;
    glRotatef(t, 0.5, 10, 0);
    glTranslatef(0, 0.1, -(t/1000));
//    glTranslatef(0, 0.1, 0);
    t += 1;
    
    // Drawing code from the header:
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glVertexPointer(3, GL_FLOAT, sizeof(TexturedVertexData3D), &MeshVertexData[0].vertex);
    glNormalPointer(GL_FLOAT, sizeof(TexturedVertexData3D), &MeshVertexData[0].normal);
    glTexCoordPointer(2, GL_FLOAT, sizeof(TexturedVertexData3D), &MeshVertexData[0].texCoord);
    int quantidadeVertices = sizeof(MeshVertexData)/sizeof(*MeshVertexData);
    glDrawArrays(GL_TRIANGLES, 0, quantidadeVertices);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    
}
-(void)setupView:(GLView*)view
{
	const GLfloat zNear = 0.01, zFar = 1000.0, fieldOfView = 45.0; 
	GLfloat size; 
    self.texture = [[OpenGLTexture3D alloc] initWithFilename:@"Earth.jpg"
                                                       width:0
                                                      height:0];
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION); 
	size = zNear * tanf(DEGREES_TO_RADIANS(fieldOfView) / 2.0); 
	CGRect rect = view.bounds; 
	glFrustumf(-size, size, -size / (rect.size.width / rect.size.height), size / 
			   (rect.size.width / rect.size.height), zNear, zFar); 
	glViewport(0, 0, rect.size.width, rect.size.height);  
	glMatrixMode(GL_MODELVIEW);
	
	glLoadIdentity(); 
}

@end
