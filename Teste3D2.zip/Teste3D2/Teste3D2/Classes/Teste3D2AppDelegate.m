//
//  Teste3D2AppDelegate.m
//  Teste3D2
//
//  Created by Hamlet Pessoa Farias Junior on 04/12/11.
//  Copyright Individual 2011. All rights reserved.
//

#import "Teste3D2AppDelegate.h"
#import "GLView.h"
#import "OpenGLCommon.h"

@implementation Teste3D2AppDelegate

@synthesize window;
@synthesize glView;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
    
	glView.animationInterval = 1.0 / kRenderingFrequency;
	[glView startAnimation];
}


- (void)applicationWillResignActive:(UIApplication *)application {
	glView.animationInterval = 1.0 / kInactiveRenderingFrequency;
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
	glView.animationInterval = 1.0 / 60.0;
}



@end
